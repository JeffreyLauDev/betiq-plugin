1. Open Chrome and go to chrome://extensions/
2. Enable "Developer mode" (toggle in top right)
3. Click "Load unpacked"
4. Select the betiq-plugin directory
5. Navigate to https://betiq.vercel.app/